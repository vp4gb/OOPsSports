package inheritance;

public class Player {
   
private int age;
private String name;
public void setAge(int a)
{ age=a;}
public void setName(String n)
{name =n;}
public int getAge()
{return(age);}
public String getName()
{ return(name);}
void Play(){
	System.out.println("this Player is great");
}

}
