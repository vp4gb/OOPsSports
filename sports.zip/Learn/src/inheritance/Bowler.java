package inheritance;

class Bowler extends Player 
{
double avg2;

public double Avg2(int run,int wck)
{
	System.out.println("i m in Bowler");
avg2=run/wck;
return avg2;	
}
}


 
